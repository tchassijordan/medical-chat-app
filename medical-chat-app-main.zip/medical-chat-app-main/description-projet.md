<body lang="fr-FR" dir="ltr">
<p align="center" style="margin-bottom: 0.28cm; line-height: 108%"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Unité
d’enseignement&nbsp;: INF3055</b></font></font></p>
<p align="center" style="margin-bottom: 0.28cm; line-height: 108%"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Année
académique&nbsp;: 2021/2011</b></font></font></p>
<p align="center" style="margin-bottom: 0.28cm; line-height: 108%"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Projet
de synthèse</b></font></font></p>
<p align="center" style="margin-bottom: 0.28cm; line-height: 108%"> 
</p>
<ol>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Titre
	du projet</b>&nbsp;</font></font></p>
</ol>
<p align="justify" style="margin-left: 0.64cm; margin-bottom: 0cm; border: none; padding: 0cm; line-height: 100%; page-break-after: avoid">
<span style="display: inline-block; border: none; padding: 0cm"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><font color="#000000"><i><span style="font-weight: normal">De
</span></i><i><span style="font-weight: normal">CRÉATION</span></i><i><span style="font-weight: normal">
D’UNE PLATEFORME </span></i><i><span style="font-weight: normal">DE
RENCONTRE</span></i><i><span style="font-weight: normal"> ENTRE
PERSONNELS DE SANTE ET PATIENTS</span></i></span></font></font></font></p>
<p align="justify" style="margin-left: 0.64cm; margin-bottom: 0.28cm; line-height: 108%">
<br/>
<br/>

</p>
<ol start="2">
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Bénéficiaires
	</b>&nbsp;</font></font></p>
</ol>
<ul>
	<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"><font color="#000000"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>Le
	présent projet est développé à l’attention de:</i></font></font></font></p>
	<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"><font color="#000000"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>-l’administration
	publique;</i></font></font></font></p>
	<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"><font color="#000000"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>-des
	personnels sanitaires;</i></font></font></font></p>
	<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"><font color="#000000"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>-des
	patients résidant sur l’étendue du territoire national.</i></font></font></font></p>
</ul>
<p align="justify" style="margin-left: 0.64cm; margin-bottom: 0.28cm; line-height: 108%">
<br/>
<br/>

</p>
<ol start="3">
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Equipe
	de développement </b></font></font>
	</p>
</ol>


Num | Noms 			et prénoms | Matricule
-- | -- | --
1 |  Nzokeu Ngouanea Brice Guenole | 18T2415  
2 |   Miessok Eric Cedric Junior            | 18T2523
3 | Kamta Blerio cabrel  |  18t2731
4 |  Jou Tchassi Idriss Jordan  |  18T2484
5 |   Manpho ngueda murhiell |  21S2783


<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"><br/>
<br/>

</p>
<ol start="4">
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Description
	du projet </b></font></font>
	</p>
	<ol>
		<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
		<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Contexte
		et enjeux du projet</b></font></font></p>
	</ol>
</ol>
<ul>
	<p align="justify" style="margin-top: 0.01cm; margin-bottom: 0cm"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt">La
	peur de se rendre dans une structure hospitalière lorsque l’on
	souffre d’un problème est devenue une véritable phobie. Cette
	phobie est créée par plusieurs raisons&nbsp;: La perte de temps&nbsp;:
	avec les files d’attente, on se rend compte qu’a l’hôpital on
	va perdre toute sa journée</font></font></p>
	<p align="justify" style="margin-top: 0.01cm; margin-bottom: 0cm"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>La
	crise de confiance entre les patients et les personnels de la </i><i>santé</i><i>
	qui s’aggravent avec les scandales qui se deviennent de plus en
	plus récurrents et balancer sur les réseaux sociaux Le covid 19
	qui a créé une crainte encore beaucoup plus grande lorsqu’on se
	rend dans une structure hospitalière. </i></font></font>
	</p>
</ul>
<ol>
	<ol>
		<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
		<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Problème
		</b></font></font>
		</p>
	</ol>
	<p align="justify" style="margin-top: 0.01cm; margin-bottom: 0cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt">C’est
	en observant ces problèmes que nous avons décidé de mettre sur
	pied une plateforme de rencontre entre professionnels de sante et
	patients. Il s’agit d’une plateforme qui va créer une proximité
	entre le patient (ou le potentiel patient) et le professionnel de
	sante de différents domaines de la sante (dermatologue,
	psychologue, pédiatre, médecins généralistes…). Les
	professionnels de sante seront disponibles 24/24 et répondront a
	toutes les questions posées par les patients.</font></font></p>
	<p align="justify" style="margin-top: 0.01cm; margin-bottom: 0cm"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt">Pour
	utiliser la plateforme il suffira d’accéder au site web puis
	choisir un médecin de la plateforme selon votre pathologie et lui
	poser votre problème de santé qui peut être tabou, car par fois
	il suffit de faire de simples analyses pour trouver de quoi l’on
	souffre et ainsi soigner.</font></font></p>
	<p align="justify" style="margin-top: 0.01cm; margin-bottom: 0cm"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt">La
	possibilité aussi de programmer un rdv a domicile ou au cabinet
	pour vous diagnostiquer.</font></font></p>
	<p align="justify" style="margin-top: 0.01cm; margin-bottom: 0cm"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>La
	plateforme vous permet aussi d’avoir la bonne information
	provenant d’une personne qui a la compétence et l’expérience
	dans son domaine.  </i></font></font>
	</p>
	<ol>
		<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
		<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Objectifs
		et résultats attendus</b></font></font></p>
	</ol>
</ol>
<ul>
	<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"><font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>l’objectif
	de notre projet c’est de permettre aux patients et aux personnels
	de la santé de gagner en temps par le biais de cette plateforme.
	Pour cela nous allons créer une plateforme consultable sur web via
	une adresse URL par les patients et les médecins.</i></font></font></p>
	<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"></p>
</ul>
<ol>
	<ol>
		<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
		<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><b>Choix
		Techniques et justifications</b></font></font></p>
	</ol>
</ol>
<ul>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>pour
	notre projet, nous allons utiliser des technologies web telques&nbsp;:</i></font></font></p>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>-php&nbsp;:
	pour rendre l’application dynamique et utilisable du cote serveur</i></font></font></p>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>html
	5&nbsp;: pour créer le squelette de notre application</i></font></font></p>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>css3
	pour la presentation de nos pages web</i></font></font></p>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>mysql&nbsp;:
	pour la creation de la bases de donnee de notre application</i></font></font></p>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>boostrap
	qui est un framework css permettant de créer créer des design
	professionnels pour les applications web</i></font></font></p>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>jquery&nbsp;:
	pour créer de l’interraction ainsi qu’une bonne experience
	utilisateur sur notre application.</i></font></font></p>
	<li/>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%">
	<font face="FreeSerif, serif"><font size="4" style="font-size: 14pt"><i>Ajax&nbsp;:
	elle va nous permettre d’execuetr certaines fonctions de maniere
	asynchrone sur notre applications</i></font></font></p>
</ul>
<p align="justify" style="margin-left: 1.4cm; margin-bottom: 0.28cm; line-height: 108%">
<br/>
<br/>

</p>
<p align="justify" style="margin-bottom: 0.28cm; line-height: 108%"><br/>
<br/>

</p>
<p align="justify" style="text-indent: 0.64cm; margin-bottom: 0.28cm; line-height: 108%">
 
</p>
</body>
</html>
